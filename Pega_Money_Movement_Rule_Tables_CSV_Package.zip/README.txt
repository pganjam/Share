PEGA MONEY MOVEMENT RULE DATA — DESIGN BASELINE (v1.0)

Purpose
  Seed Pega question catalog and static option data records; supply developer-ready
  decision-table row specifications for JOURNAL, ACH, WIRE and NEXT QUESTION.
  All bank eligibility rules are illustrative and require SME/security approval.

Files
  Pega_MM_Decision_Table_Rules.csv   Combined rule row reference (30? rows)
  DT_JournalCandidate.csv            Journal decision-table source rows
  DT_ACHCandidate.csv                ACH decision-table source rows
  DT_WireCandidate.csv               Wire decision-table source rows
  DT_NextQuestion.csv                Next question priority rules
  Pega_MM_Question_Catalog.csv       Question data-type records
  Pega_MM_Static_Options.csv         Static choice records
  Pega_MM_Field_Requirements.csv     Conditional field requirements by rail
  Pega_MM_Test_Cases.csv             Test cases (unit and integration)

IMPORTANT — Pega import behavior
  Question Catalog, Static Options, and Field Requirements are data-record CSVs.
  Create corresponding Pega data types with matching property names and keys,
  then map columns through supported data import tools.

  Decision Table rule-form import in Pega uses an Excel template exported from
  that *same Pega rule*, not an arbitrary CSV. DT_*.csv files here are
  IMPLEMENTATION SOURCE DATA, not a direct Rule form import file. Create the
  rule, export its Excel template, map these rows to Pega conditions/results,
  and re-import the edited exported template or enter rows in Dev Studio.
  ConditionExpression is human-readable requirements syntax, NOT executable
  Pega expressions. Translate into Pega properties / When rules.

Recommended Pega data model keys
  QuestionCatalog: QuestionId + RuleVersion
  StaticOptions: OptionsResolver + OptionValue
  FieldRequirements: Rail + FieldPath

Decision execution principles
  1. Evaluate Journal, ACH, and Wire independently (multiple candidates allowed).
  2. UNKNOWN is distinct from FALSE; do not default UNKNOWN to INELIGIBLE.
  3. Enforce first-match/priority ordering; OTHERWISE is the final fallback.
  4. Required-field rules apply to currently viable rails; the user may need
     a rail/delivery choice if several remain.
  5. Resolve dynamic account/beneficiary options in Spring Boot from trusted services.
  6. Pega COMPLETE means questionnaire complete, not authorization to transfer.
  7. Frontend does not provide authoritative advisorId or channel.

References
  Pega decision table rule-form import/export guidance:
    https://docs.pega.com/bundle/platform-25/page/platform/decision-management/complete-table-tab.html?workflow=using-decision-tables-and-decision-trees
  Pega data records / CSV import guidance:
    https://community.pega.com/sites/pdn.pega.com/files/help_v85/oxy_ex-1/platform-helpsystem/data-integration/app-data/dm-importing-data-from-a-file-tsk.htm

All identifiers and policies are examples; do not treat this package as
production approved, a bank-specific eligibility matrix or a native Pega package.
